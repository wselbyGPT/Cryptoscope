# SymmCrypt TUI

A robust WSL-friendly symmetric encryption toolkit in Python with:

- a **curses TUI** for interactive workflows
- production-grade authenticated encryption via **AES-256-GCM** and **ChaCha20-Poly1305**
- a highly configurable **custom cipher lab** for experimenting with rounds, rotations, block sizes, whitening, modes, and seeded S-box behavior
- file header inspection, saved profiles, and built-in round-trip benchmarks

## Important note

The `custom-lab` algorithm is intentionally exposed for experimentation and learning. It is **not** a substitute for a professionally analyzed cipher. For real protection, use:

- `aes-gcm`
- `chacha20-poly1305`

## Project tree

```text
symmcrypt_tui/
├── README.md
├── requirements.txt
├── run.py
└── symmcrypt/
    ├── __init__.py
    ├── app.py
    ├── benchmark.py
    ├── cli.py
    ├── config_io.py
    ├── kdf.py
    ├── models.py
    ├── storage.py
    ├── tui.py
    ├── util.py
    ├── workflows.py
    └── engines/
        ├── __init__.py
        ├── aes_gcm_engine.py
        ├── chacha_engine.py
        └── custom_lab_engine.py
```

## Install on WSL Ubuntu

```bash
cd ~/Downloads
unzip symmcrypt_tui.zip
cd symmcrypt_tui
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Launch the TUI

```bash
python3 run.py tui
```

Controls:

- `↑/↓` or `j/k` move through fields
- `Enter` edits a field
- `Space` toggles bools or cycles choice fields
- `r` runs encrypt/decrypt
- `b` benchmarks all algorithms
- `s` saves a profile to `~/.symmcrypt_profiles/`
- `l` loads a profile
- `q` quits

## CLI examples

### Encrypt a file with AES-GCM

```bash
python3 run.py encrypt \
  --algorithm aes-gcm \
  --password 'correct horse battery staple' \
  --in ./notes.txt \
  --out ./notes.txt.sym
```

### Decrypt it

```bash
python3 run.py decrypt \
  --password 'correct horse battery staple' \
  --in ./notes.txt.sym \
  --out ./notes.dec.txt
```

### Use a keyfile too

```bash
python3 run.py encrypt \
  --algorithm chacha20-poly1305 \
  --password 'my passphrase' \
  --keyfile ~/.ssh/id_ed25519.pub \
  --aad 'project=perceptrome' \
  --in ./dataset.bin
```

### Experiment with the custom lab cipher

```bash
python3 run.py encrypt \
  --algorithm custom-lab \
  --password 'lab-pass' \
  --mode CTR \
  --rounds 20 \
  --block-bits 256 \
  --rot-a 7 \
  --rot-b 19 \
  --sbox-seed 424242 \
  --round-constant 0x9E3779B97F4A7C15 \
  --in ./sample.bin \
  --out ./sample.lab.sym
```

### Benchmark

```bash
python3 run.py bench --password 'bench-pass'
```


### Analyze custom-lab avalanche behavior

```bash
python3 run.py analyze   --password 'lab-pass'   --rounds 20   --block-bits 256   --rot-a 7   --rot-b 19
```

### TUI text mode

Set `target` to `text`, put plaintext into `Text input`, and run encrypt. The encrypted result is shown as a base64 envelope in the status area so you can copy it back in for decryption.

### Inspect encrypted header metadata

```bash
python3 run.py inspect --in ./sample.lab.sym
```

## Envelope format

Encrypted files use a simple self-describing container:

- magic: `SYMKT1\0`
- 4-byte big-endian JSON header length
- JSON header
- ciphertext bytes

The JSON header stores the algorithm, KDF details, salt, AAD, and per-algorithm extras like nonce, IV, tag, or custom-lab params.

## Good defaults

For actual use:

- algorithm: `aes-gcm` or `chacha20-poly1305`
- kdf: `scrypt`
- optional keyfile for defense-in-depth

For experimentation:

- algorithm: `custom-lab`
- mode: `CTR` if you want streaming-like behavior
- mode: `CBC` if you want padded block behavior
- rounds: 12, 16, 20, or 32
- block bits: 128 or 256

## Security caveats

- Never trust the custom lab cipher for serious security.
- Changing rounds/rotations/seeds makes the algorithm *different*, not automatically *stronger*.
- Reusing the wrong password or keyfile will fail decryption; authenticated modes also detect tampering.
- The header reveals metadata like algorithm and KDF settings by design. The contents remain encrypted.

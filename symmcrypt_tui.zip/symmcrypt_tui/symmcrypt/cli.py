from __future__ import annotations

import argparse
import sys

from .benchmark import run_benchmarks, run_custom_lab_analysis
from .models import CryptoJob
from .tui import launch_tui
from .workflows import decrypt_job, encrypt_job, inspect_file



def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description='Symmetric encryption toolkit with curses TUI and cipher lab.')
    sub = p.add_subparsers(dest='command', required=True)

    sub.add_parser('tui', help='Launch the curses interface.')

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument('--algorithm', default='aes-gcm', choices=['aes-gcm', 'chacha20-poly1305', 'custom-lab'])
    common.add_argument('--password', required=True)
    common.add_argument('--keyfile', default='')
    common.add_argument('--aad', default='')
    common.add_argument('--overwrite', action='store_true')
    common.add_argument('--salt-bytes', type=int, default=16)
    common.add_argument('--key-len', type=int, default=32)
    common.add_argument('--kdf', default='scrypt', choices=['scrypt', 'pbkdf2'])
    common.add_argument('--scrypt-n', type=int, default=2**15)
    common.add_argument('--scrypt-r', type=int, default=8)
    common.add_argument('--scrypt-p', type=int, default=1)
    common.add_argument('--pbkdf2-iters', type=int, default=200000)
    common.add_argument('--rounds', type=int, default=12)
    common.add_argument('--block-bits', type=int, default=128, choices=[64, 128, 256])
    common.add_argument('--rot-a', type=int, default=5)
    common.add_argument('--rot-b', type=int, default=11)
    common.add_argument('--mode', default='CBC', choices=['ECB', 'CBC', 'CTR'])
    common.add_argument('--sbox-seed', type=int, default=1337)
    common.add_argument('--ctr-init', type=int, default=0)
    common.add_argument('--round-constant', type=lambda x: int(x, 0), default=0x9E3779B9)
    common.add_argument('--disable-padding', action='store_true')
    common.add_argument('--disable-whitening', action='store_true')

    enc = sub.add_parser('encrypt', parents=[common], help='Encrypt a file.')
    enc.add_argument('--in', dest='input_path', required=True)
    enc.add_argument('--out', dest='output_path', default='')

    dec = sub.add_parser('decrypt', parents=[common], help='Decrypt a file.')
    dec.add_argument('--in', dest='input_path', required=True)
    dec.add_argument('--out', dest='output_path', default='')

    bench = sub.add_parser('bench', parents=[common], help='Run round-trip benchmarks.')
    sub.add_parser('analyze', parents=[common], help='Analyze custom-lab avalanche behavior.')

    insp = sub.add_parser('inspect', help='Inspect encrypted header metadata.')
    insp.add_argument('--in', dest='input_path', required=True)
    return p



def job_from_args(args: argparse.Namespace, operation: str = 'encrypt') -> CryptoJob:
    job = CryptoJob()
    job.operation = operation
    job.algorithm = getattr(args, 'algorithm', job.algorithm)
    job.password = getattr(args, 'password', '')
    job.keyfile_path = getattr(args, 'keyfile', '')
    job.associated_data = getattr(args, 'aad', '')
    job.overwrite = getattr(args, 'overwrite', False)
    job.kdf.name = getattr(args, 'kdf', 'scrypt')
    job.kdf.salt_bytes = getattr(args, 'salt_bytes', job.kdf.salt_bytes)
    job.kdf.key_len = getattr(args, 'key_len', job.kdf.key_len)
    job.kdf.n = getattr(args, 'scrypt_n', job.kdf.n)
    job.kdf.r = getattr(args, 'scrypt_r', job.kdf.r)
    job.kdf.p = getattr(args, 'scrypt_p', job.kdf.p)
    job.kdf.iterations = getattr(args, 'pbkdf2_iters', job.kdf.iterations)
    job.input_path = getattr(args, 'input_path', '')
    job.output_path = getattr(args, 'output_path', '')
    job.custom.rounds = getattr(args, 'rounds', job.custom.rounds)
    job.custom.block_size_bits = getattr(args, 'block_bits', job.custom.block_size_bits)
    job.custom.rotation_a = getattr(args, 'rot_a', job.custom.rotation_a)
    job.custom.rotation_b = getattr(args, 'rot_b', job.custom.rotation_b)
    job.custom.mode = getattr(args, 'mode', job.custom.mode)
    job.custom.sbox_seed = getattr(args, 'sbox_seed', job.custom.sbox_seed)
    job.custom.ctr_initial_value = getattr(args, 'ctr_init', job.custom.ctr_initial_value)
    job.custom.round_constant = getattr(args, 'round_constant', job.custom.round_constant)
    job.custom.use_padding = not getattr(args, 'disable_padding', False)
    job.custom.whitening = not getattr(args, 'disable_whitening', False)
    return job



def run_cli(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == 'tui':
        return launch_tui()
    if args.command == 'inspect':
        print(inspect_file(args.input_path))
        return 0
    if args.command == 'bench':
        job = job_from_args(args, 'encrypt')
        for line in run_benchmarks(job):
            print(line)
        return 0
    if args.command == 'analyze':
        job = job_from_args(args, 'encrypt')
        for line in run_custom_lab_analysis(job):
            print(line)
        return 0
    if args.command == 'encrypt':
        job = job_from_args(args, 'encrypt')
        res = encrypt_job(job)
    else:
        job = job_from_args(args, 'decrypt')
        res = decrypt_job(job)
    print(res.message)
    return 0 if res.ok else 1

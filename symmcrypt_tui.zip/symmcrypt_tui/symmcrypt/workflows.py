from __future__ import annotations

import os
from typing import Any, Dict, Tuple

from .engines import build_registry
from .kdf import derive_key
from .models import CryptoJob, ResultBundle
from .storage import pack_envelope, unpack_envelope
from .util import b64d, b64e, ensure_parent, load_keyfile, pretty_json


REGISTRY = build_registry()



def encrypt_bytes(job: CryptoJob, plaintext: bytes) -> Tuple[bytes, Dict[str, Any]]:
    keyfile = load_keyfile(job.keyfile_path)
    key, salt = derive_key(job.password, keyfile, job.kdf)
    engine = REGISTRY[job.algorithm]
    params = {
        'associated_data': job.associated_data.encode('utf-8'),
        'custom': job.custom,
        'custom_params': job.custom,
    }
    result = engine.encrypt(plaintext, key, params)
    header = {
        'algorithm': job.algorithm,
        'kdf': job.kdf.__dict__,
        'salt': b64e(salt),
        'aad': job.associated_data,
        'extras': {
            k: (b64e(v) if isinstance(v, (bytes, bytearray)) else v)
            for k, v in result['header'].items()
        },
    }
    blob = pack_envelope(header, result['ciphertext'])
    return blob, header



def decrypt_bytes(job: CryptoJob, blob: bytes, header: Dict[str, Any] | None = None) -> bytes:
    header, ciphertext = unpack_envelope(blob)
    job.algorithm = header['algorithm']
    job.kdf = job.kdf.__class__(**header['kdf'])
    job.associated_data = header.get('aad', '')
    extras = {
        k: (b64d(v) if isinstance(v, str) and k in {'nonce', 'tag', 'iv'} else v)
        for k, v in header.get('extras', {}).items()
    }
    keyfile = load_keyfile(job.keyfile_path)
    key, _ = derive_key(job.password, keyfile, job.kdf, salt=b64d(header['salt']))
    engine = REGISTRY[job.algorithm]
    extras['associated_data'] = job.associated_data.encode('utf-8')
    return engine.decrypt(ciphertext, key, extras)



def encrypt_job(job: CryptoJob) -> ResultBundle:
    try:
        if not job.password:
            return ResultBundle(False, 'Password is required.')
        if job.target == 'file':
            with open(os.path.expanduser(job.input_path), 'rb') as fh:
                plaintext = fh.read()
        else:
            plaintext = job.text_input.encode('utf-8')
        blob, header = encrypt_bytes(job, plaintext)
        if job.target == 'file':
            out_path = os.path.expanduser(job.output_path or (job.input_path + '.sym'))
            ensure_parent(out_path)
            if os.path.exists(out_path) and not job.overwrite:
                return ResultBundle(False, f'Output already exists: {out_path}. Enable overwrite or change path.')
            with open(out_path, 'wb') as fh:
                fh.write(blob)
            return ResultBundle(True, f'Encrypted {len(plaintext)} bytes -> {out_path}', output_path=out_path, metadata=header)
        return ResultBundle(True, 'Encrypted text payload.', plaintext=b64e(blob).encode('ascii'), metadata=header)
    except Exception as exc:
        return ResultBundle(False, f'Encryption failed: {exc}')



def decrypt_job(job: CryptoJob) -> ResultBundle:
    try:
        if not job.password:
            return ResultBundle(False, 'Password is required.')
        if job.target == 'file':
            with open(os.path.expanduser(job.input_path), 'rb') as fh:
                blob = fh.read()
        else:
            blob = b64d(job.text_input.strip())
        plaintext = decrypt_bytes(job, blob)
        if job.target == 'file':
            out_path = os.path.expanduser(job.output_path or (job.input_path + '.dec'))
            ensure_parent(out_path)
            if os.path.exists(out_path) and not job.overwrite:
                return ResultBundle(False, f'Output already exists: {out_path}. Enable overwrite or change path.')
            with open(out_path, 'wb') as fh:
                fh.write(plaintext)
            return ResultBundle(True, f'Decrypted {len(plaintext)} bytes -> {out_path}', output_path=out_path)
        return ResultBundle(True, 'Decrypted text payload.', plaintext=plaintext)
    except Exception as exc:
        return ResultBundle(False, f'Decryption failed: {exc}')



def inspect_file(path: str) -> str:
    with open(os.path.expanduser(path), 'rb') as fh:
        blob = fh.read()
    header, ciphertext = unpack_envelope(blob)
    header['ciphertext_bytes'] = len(ciphertext)
    return pretty_json(header)

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class KDFConfig:
    name: str = 'scrypt'
    salt_bytes: int = 16
    key_len: int = 32
    n: int = 2**15
    r: int = 8
    p: int = 1
    iterations: int = 200_000


@dataclass
class CustomCipherConfig:
    block_size_bits: int = 128
    rounds: int = 12
    rotation_a: int = 5
    rotation_b: int = 11
    whitening: bool = True
    mode: str = 'CBC'
    ctr_initial_value: int = 0
    sbox_seed: int = 1337
    round_constant: int = 0x9E3779B9
    use_padding: bool = True


@dataclass
class CryptoJob:
    operation: str = 'encrypt'
    target: str = 'file'
    algorithm: str = 'aes-gcm'
    input_path: str = ''
    output_path: str = ''
    text_input: str = ''
    password: str = ''
    keyfile_path: str = ''
    kdf: KDFConfig = field(default_factory=KDFConfig)
    custom: CustomCipherConfig = field(default_factory=CustomCipherConfig)
    associated_data: str = ''
    overwrite: bool = False
    profile_name: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        return data

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> 'CryptoJob':
        kdf = KDFConfig(**payload.get('kdf', {}))
        custom = CustomCipherConfig(**payload.get('custom', {}))
        payload = dict(payload)
        payload['kdf'] = kdf
        payload['custom'] = custom
        return cls(**payload)


@dataclass
class ResultBundle:
    ok: bool
    message: str
    output_path: Optional[str] = None
    plaintext: Optional[bytes] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    details: List[str] = field(default_factory=list)

from __future__ import annotations

import os
import time
from typing import List

from .engines import build_registry
from .kdf import derive_key
from .models import CryptoJob
from .workflows import decrypt_bytes, encrypt_bytes
from .util import human_bytes, load_keyfile



def run_benchmarks(job: CryptoJob, sizes: List[int] | None = None) -> List[str]:
    sizes = sizes or [1024, 16 * 1024, 128 * 1024]
    registry = build_registry()
    lines: List[str] = []
    for algo in registry:
        bench_job = CryptoJob.from_dict(job.to_dict())
        bench_job.algorithm = algo
        lines.append(f'[{algo}]')
        for size in sizes:
            payload = os.urandom(size)
            t0 = time.perf_counter()
            blob, _ = encrypt_bytes(bench_job, payload)
            t1 = time.perf_counter()
            roundtrip = decrypt_bytes(bench_job, blob)
            t2 = time.perf_counter()
            assert roundtrip == payload
            enc_ms = (t1 - t0) * 1000
            dec_ms = (t2 - t1) * 1000
            lines.append(f'  {size:>8} bytes  enc={enc_ms:8.3f} ms  dec={dec_ms:8.3f} ms')
    return lines



def run_custom_lab_analysis(job: CryptoJob) -> List[str]:
    registry = build_registry()
    engine = registry['custom-lab']
    lab_job = CryptoJob.from_dict(job.to_dict())
    lab_job.algorithm = 'custom-lab'
    keyfile = load_keyfile(lab_job.keyfile_path)
    key, _ = derive_key(lab_job.password or 'analysis-pass', keyfile, lab_job.kdf, salt=b'\x00' * lab_job.kdf.salt_bytes)
    cfg = lab_job.custom
    block_bytes = cfg.block_size_bits // 8
    sbox = engine._make_sbox(cfg)
    round_keys = engine._expand_round_keys(key, cfg)
    base = os.urandom(block_bytes)
    flipped_plain = bytearray(base)
    flipped_plain[0] ^= 0x01
    flipped_key = bytearray(key)
    flipped_key[0] ^= 0x01
    round_keys_alt = engine._expand_round_keys(bytes(flipped_key), cfg)
    c1 = engine._enc_block(base, round_keys, cfg, sbox)
    c2 = engine._enc_block(bytes(flipped_plain), round_keys, cfg, sbox)
    c3 = engine._enc_block(base, round_keys_alt, cfg, sbox)

    def bitdiff(a: bytes, b: bytes) -> int:
        return sum((x ^ y).bit_count() for x, y in zip(a, b))

    total_bits = block_bytes * 8
    pdiff = bitdiff(c1, c2)
    kdiff = bitdiff(c1, c3)
    return [
        '[custom-lab analysis]',
        f'  block size: {cfg.block_size_bits} bits',
        f'  rounds:     {cfg.rounds}',
        f'  mode:       {cfg.mode}',
        f'  rotation A/B: {cfg.rotation_a}/{cfg.rotation_b}',
        f'  plain-bit flip avalanche: {pdiff}/{total_bits} bits ({(100*pdiff/total_bits):.2f}%)',
        f'  key-bit flip avalanche:   {kdiff}/{total_bits} bits ({(100*kdiff/total_bits):.2f}%)',
    ]

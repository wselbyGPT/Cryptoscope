from __future__ import annotations

import json
from pathlib import Path

from .models import CryptoJob


PROFILE_DIR = Path.home() / '.symmcrypt_profiles'


def save_profile(job: CryptoJob, name: str) -> Path:
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    path = PROFILE_DIR / f'{name}.json'
    payload = job.to_dict()
    payload['password'] = ''
    path.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    return path



def load_profile(name: str) -> CryptoJob:
    path = PROFILE_DIR / f'{name}.json'
    payload = json.loads(path.read_text(encoding='utf-8'))
    return CryptoJob.from_dict(payload)



def list_profiles() -> list[str]:
    if not PROFILE_DIR.exists():
        return []
    return sorted(p.stem for p in PROFILE_DIR.glob('*.json'))

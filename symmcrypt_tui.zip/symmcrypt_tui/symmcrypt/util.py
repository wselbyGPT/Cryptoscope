from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
from typing import Any, Dict


MAGIC = b'SYMKT1\0'


def b64e(data: bytes) -> str:
    return base64.b64encode(data).decode('ascii')


def b64d(data: str) -> bytes:
    return base64.b64decode(data.encode('ascii'))


def ensure_parent(path: str) -> None:
    Path(path).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)


def file_digest(path: str) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load_keyfile(path: str) -> bytes:
    if not path:
        return b''
    with open(os.path.expanduser(path), 'rb') as fh:
        return fh.read()


def pretty_json(data: Dict[str, Any]) -> str:
    return json.dumps(data, indent=2, sort_keys=True)


def human_bytes(n: int) -> str:
    units = ['B', 'KiB', 'MiB', 'GiB', 'TiB']
    value = float(n)
    idx = 0
    while value >= 1024 and idx < len(units) - 1:
        value /= 1024.0
        idx += 1
    return f'{value:.2f} {units[idx]}'

from .aes_gcm_engine import AESGCMEngine
from .chacha_engine import ChaCha20Poly1305Engine
from .custom_lab_engine import CustomLabEngine


def build_registry():
    engines = [AESGCMEngine(), ChaCha20Poly1305Engine(), CustomLabEngine()]
    return {engine.name: engine for engine in engines}

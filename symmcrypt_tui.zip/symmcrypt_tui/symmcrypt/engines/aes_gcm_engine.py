from __future__ import annotations

import secrets
from typing import Any, Dict

from Crypto.Cipher import AES


class AESGCMEngine:
    name = 'aes-gcm'
    description = 'Authenticated AES-256-GCM for production use.'

    def encrypt(self, plaintext: bytes, key: bytes, params: Dict[str, Any]) -> Dict[str, Any]:
        nonce = secrets.token_bytes(12)
        cipher = AES.new(key[:32], AES.MODE_GCM, nonce=nonce)
        aad = params.get('associated_data', b'')
        if aad:
            cipher.update(aad)
        ciphertext, tag = cipher.encrypt_and_digest(plaintext)
        return {
            'ciphertext': ciphertext,
            'header': {
                'nonce': nonce,
                'tag': tag,
                'mode': 'GCM',
            },
        }

    def decrypt(self, ciphertext: bytes, key: bytes, params: Dict[str, Any]) -> bytes:
        nonce = params['nonce']
        tag = params['tag']
        aad = params.get('associated_data', b'')
        cipher = AES.new(key[:32], AES.MODE_GCM, nonce=nonce)
        if aad:
            cipher.update(aad)
        return cipher.decrypt_and_verify(ciphertext, tag)

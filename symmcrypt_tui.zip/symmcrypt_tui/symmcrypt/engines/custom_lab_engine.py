from __future__ import annotations

import hashlib
import secrets
from dataclasses import asdict
from typing import Any, Dict, List

from ..models import CustomCipherConfig


class CustomLabEngine:
    name = 'custom-lab'
    description = 'Experimental Feistel cipher lab. Educational only; not real-world secure.'

    def encrypt(self, plaintext: bytes, key: bytes, params: Dict[str, Any]) -> Dict[str, Any]:
        cfg = self._cfg(params)
        block_bytes = cfg.block_size_bits // 8
        mode = cfg.mode.upper()
        iv = secrets.token_bytes(block_bytes)
        if mode in {'ECB', 'CBC'} and cfg.use_padding:
            plaintext = self._pkcs7_pad(plaintext, block_bytes)
        elif mode in {'ECB', 'CBC'} and len(plaintext) % block_bytes != 0:
            raise ValueError('Plaintext length must be a multiple of block size when padding is disabled.')
        round_keys = self._expand_round_keys(key, cfg)
        sbox = self._make_sbox(cfg)
        if mode == 'ECB':
            out = b''.join(self._enc_block(plaintext[i:i + block_bytes], round_keys, cfg, sbox) for i in range(0, len(plaintext), block_bytes))
        elif mode == 'CBC':
            out = self._cbc_encrypt(plaintext, iv, round_keys, cfg, sbox)
        elif mode == 'CTR':
            out = self._ctr_crypt(plaintext, iv, round_keys, cfg, sbox)
        else:
            raise ValueError(f'Unsupported custom mode: {mode}')
        return {
            'ciphertext': out,
            'header': {
                'iv': iv,
                'mode': mode,
                'custom_params': asdict(cfg),
            },
        }

    def decrypt(self, ciphertext: bytes, key: bytes, params: Dict[str, Any]) -> bytes:
        cfg = self._cfg(params)
        block_bytes = cfg.block_size_bits // 8
        mode = cfg.mode.upper()
        iv = params['iv']
        round_keys = self._expand_round_keys(key, cfg)
        sbox = self._make_sbox(cfg)
        if mode == 'ECB':
            out = b''.join(self._dec_block(ciphertext[i:i + block_bytes], round_keys, cfg, sbox) for i in range(0, len(ciphertext), block_bytes))
        elif mode == 'CBC':
            out = self._cbc_decrypt(ciphertext, iv, round_keys, cfg, sbox)
        elif mode == 'CTR':
            out = self._ctr_crypt(ciphertext, iv, round_keys, cfg, sbox)
        else:
            raise ValueError(f'Unsupported custom mode: {mode}')
        if mode in {'ECB', 'CBC'} and cfg.use_padding:
            out = self._pkcs7_unpad(out, block_bytes)
        return out

    def _cfg(self, params: Dict[str, Any]) -> CustomCipherConfig:
        custom = params.get('custom_params') or params.get('custom') or {}
        if isinstance(custom, CustomCipherConfig):
            return custom
        return CustomCipherConfig(**custom)

    def _expand_round_keys(self, key: bytes, cfg: CustomCipherConfig) -> List[int]:
        half_bits = cfg.block_size_bits // 2
        half_bytes = half_bits // 8
        mask = (1 << half_bits) - 1
        out: List[int] = []
        seed = key + cfg.sbox_seed.to_bytes(8, 'big', signed=False)
        state = hashlib.sha512(seed).digest()
        for i in range(cfg.rounds):
            state = hashlib.sha512(state + i.to_bytes(4, 'big') + cfg.round_constant.to_bytes(8, 'big', signed=False)).digest()
            out.append(int.from_bytes(state[:half_bytes], 'big') & mask)
        return out

    def _make_sbox(self, cfg: CustomCipherConfig) -> List[int]:
        seed = hashlib.sha256(f'{cfg.sbox_seed}:{cfg.round_constant}:{cfg.block_size_bits}'.encode()).digest()
        box = list(range(256))
        j = 0
        for i in range(255, 0, -1):
            j = (j + seed[i % len(seed)] + box[i]) % (i + 1)
            box[i], box[j] = box[j], box[i]
        return box

    def _substitute_int(self, value: int, width_bytes: int, sbox: List[int]) -> int:
        raw = value.to_bytes(width_bytes, 'big')
        return int.from_bytes(bytes(sbox[b] for b in raw), 'big')

    def _round_f(self, r: int, k: int, cfg: CustomCipherConfig, sbox: List[int]) -> int:
        half_bits = cfg.block_size_bits // 2
        half_bytes = half_bits // 8
        mask = (1 << half_bits) - 1
        x = (r + k + cfg.round_constant) & mask
        x ^= self._rotl(r, cfg.rotation_a % half_bits, half_bits)
        x = self._substitute_int(x, half_bytes, sbox)
        x ^= self._rotl(x, cfg.rotation_b % half_bits, half_bits)
        x = (x + ((k ^ cfg.round_constant) & mask)) & mask
        return x

    def _enc_block(self, block: bytes, round_keys: List[int], cfg: CustomCipherConfig, sbox: List[int]) -> bytes:
        half_bytes = len(block) // 2
        mask = (1 << (half_bytes * 8)) - 1
        l = int.from_bytes(block[:half_bytes], 'big')
        r = int.from_bytes(block[half_bytes:], 'big')
        if cfg.whitening:
            l ^= round_keys[0] & mask
            r ^= round_keys[-1] & mask
        for rk in round_keys:
            l, r = r, (l ^ self._round_f(r, rk, cfg, sbox)) & mask
        return l.to_bytes(half_bytes, 'big') + r.to_bytes(half_bytes, 'big')

    def _dec_block(self, block: bytes, round_keys: List[int], cfg: CustomCipherConfig, sbox: List[int]) -> bytes:
        half_bytes = len(block) // 2
        mask = (1 << (half_bytes * 8)) - 1
        l = int.from_bytes(block[:half_bytes], 'big')
        r = int.from_bytes(block[half_bytes:], 'big')
        for rk in reversed(round_keys):
            l, r = (r ^ self._round_f(l, rk, cfg, sbox)) & mask, l
        if cfg.whitening:
            l ^= round_keys[0] & mask
            r ^= round_keys[-1] & mask
        return l.to_bytes(half_bytes, 'big') + r.to_bytes(half_bytes, 'big')

    def _cbc_encrypt(self, plaintext: bytes, iv: bytes, round_keys: List[int], cfg: CustomCipherConfig, sbox: List[int]) -> bytes:
        block_bytes = len(iv)
        prev = iv
        out = []
        for i in range(0, len(plaintext), block_bytes):
            block = bytes(a ^ b for a, b in zip(plaintext[i:i + block_bytes], prev))
            enc = self._enc_block(block, round_keys, cfg, sbox)
            out.append(enc)
            prev = enc
        return b''.join(out)

    def _cbc_decrypt(self, ciphertext: bytes, iv: bytes, round_keys: List[int], cfg: CustomCipherConfig, sbox: List[int]) -> bytes:
        block_bytes = len(iv)
        prev = iv
        out = []
        for i in range(0, len(ciphertext), block_bytes):
            block = ciphertext[i:i + block_bytes]
            dec = self._dec_block(block, round_keys, cfg, sbox)
            out.append(bytes(a ^ b for a, b in zip(dec, prev)))
            prev = block
        return b''.join(out)

    def _ctr_crypt(self, data: bytes, iv: bytes, round_keys: List[int], cfg: CustomCipherConfig, sbox: List[int]) -> bytes:
        block_bytes = len(iv)
        initial = int.from_bytes(iv, 'big') ^ cfg.ctr_initial_value
        out = bytearray()
        for idx in range(0, len(data), block_bytes):
            ctr_block = ((initial + idx // block_bytes) % (1 << (block_bytes * 8))).to_bytes(block_bytes, 'big')
            stream = self._enc_block(ctr_block, round_keys, cfg, sbox)
            chunk = data[idx:idx + block_bytes]
            out.extend(bytes(a ^ b for a, b in zip(chunk, stream)))
        return bytes(out)

    @staticmethod
    def _rotl(value: int, shift: int, width: int) -> int:
        mask = (1 << width) - 1
        shift %= width
        return ((value << shift) & mask) | ((value & mask) >> (width - shift))

    @staticmethod
    def _pkcs7_pad(data: bytes, block_size: int) -> bytes:
        pad = block_size - (len(data) % block_size)
        return data + bytes([pad]) * pad

    @staticmethod
    def _pkcs7_unpad(data: bytes, block_size: int) -> bytes:
        if not data:
            raise ValueError('Invalid padded plaintext.')
        pad = data[-1]
        if pad == 0 or pad > block_size or data[-pad:] != bytes([pad]) * pad:
            raise ValueError('Invalid PKCS#7 padding.')
        return data[:-pad]

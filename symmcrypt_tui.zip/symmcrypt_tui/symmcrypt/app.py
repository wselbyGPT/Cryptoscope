from __future__ import annotations

from .cli import run_cli



def main(argv: list[str] | None = None) -> int:
    return run_cli(argv)

from __future__ import annotations

import hashlib
import secrets
from typing import Tuple

from .models import KDFConfig


def normalize_secret(password: str, keyfile_bytes: bytes) -> bytes:
    joined = password.encode('utf-8') + b'\0' + keyfile_bytes
    return hashlib.sha256(joined).digest() + joined



def derive_key(password: str, keyfile_bytes: bytes, cfg: KDFConfig, salt: bytes | None = None) -> Tuple[bytes, bytes]:
    salt = salt or secrets.token_bytes(cfg.salt_bytes)
    material = normalize_secret(password, keyfile_bytes)
    if cfg.name.lower() == 'scrypt':
        key = hashlib.scrypt(material, salt=salt, n=cfg.n, r=cfg.r, p=cfg.p, dklen=cfg.key_len, maxmem=512 * 1024 * 1024)
    elif cfg.name.lower() == 'pbkdf2':
        key = hashlib.pbkdf2_hmac('sha256', material, salt, cfg.iterations, dklen=cfg.key_len)
    else:
        raise ValueError(f'Unsupported KDF: {cfg.name}')
    return key, salt

from __future__ import annotations

import curses
import textwrap
from typing import List, Tuple

from .benchmark import run_benchmarks, run_custom_lab_analysis
from .config_io import list_profiles, load_profile, save_profile
from .models import CryptoJob
from .util import pretty_json
from .workflows import decrypt_job, encrypt_job


FIELD_SPECS: List[Tuple[str, str, str]] = [
    ('operation', 'Operation', 'choice'),
    ('target', 'Target', 'choice'),
    ('algorithm', 'Algorithm', 'choice'),
    ('input_path', 'Input path', 'text'),
    ('output_path', 'Output path', 'text'),
    ('text_input', 'Text input', 'text'),
    ('password', 'Password', 'secret'),
    ('keyfile_path', 'Keyfile path', 'text'),
    ('associated_data', 'Associated data', 'text'),
    ('kdf.name', 'KDF', 'choice'),
    ('kdf.salt_bytes', 'Salt bytes', 'int'),
    ('kdf.key_len', 'Key length', 'int'),
    ('kdf.n', 'scrypt N', 'int'),
    ('kdf.r', 'scrypt r', 'int'),
    ('kdf.p', 'scrypt p', 'int'),
    ('kdf.iterations', 'PBKDF2 iterations', 'int'),
    ('custom.mode', 'Custom mode', 'choice'),
    ('custom.block_size_bits', 'Block bits', 'int'),
    ('custom.rounds', 'Rounds', 'int'),
    ('custom.rotation_a', 'Rotate A', 'int'),
    ('custom.rotation_b', 'Rotate B', 'int'),
    ('custom.sbox_seed', 'S-box seed', 'int'),
    ('custom.ctr_initial_value', 'CTR init', 'int'),
    ('custom.round_constant', 'Round const', 'int'),
    ('custom.whitening', 'Whitening', 'bool'),
    ('custom.use_padding', 'Padding', 'bool'),
    ('overwrite', 'Overwrite', 'bool'),
]

CHOICES = {
    'operation': ['encrypt', 'decrypt'],
    'target': ['file', 'text'],
    'algorithm': ['aes-gcm', 'chacha20-poly1305', 'custom-lab'],
    'kdf.name': ['scrypt', 'pbkdf2'],
    'custom.mode': ['ECB', 'CBC', 'CTR'],
}


class TUI:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        self.job = CryptoJob()
        self.idx = 0
        self.status_lines: List[str] = [
            'Arrows move  Enter edits  Space toggles  r run  b benchmark  a analyze  s save profile  l load profile  q quit',
            'Use custom-lab only for experimentation. AES-GCM and ChaCha20-Poly1305 are the real-use options.',
        ]

    def run(self) -> int:
        curses.curs_set(0)
        self.stdscr.keypad(True)
        while True:
            self.draw()
            ch = self.stdscr.getch()
            if ch in (ord('q'), 27):
                return 0
            if ch in (curses.KEY_UP, ord('k')):
                self.idx = (self.idx - 1) % len(FIELD_SPECS)
            elif ch in (curses.KEY_DOWN, ord('j')):
                self.idx = (self.idx + 1) % len(FIELD_SPECS)
            elif ch in (ord(' '),):
                self.toggle_current()
            elif ch in (10, 13, curses.KEY_ENTER):
                self.edit_current()
            elif ch == ord('r'):
                self.execute_job()
            elif ch == ord('b'):
                self.run_benchmark()
            elif ch == ord('a'):
                self.run_analysis()
            elif ch == ord('s'):
                self.save_current_profile()
            elif ch == ord('l'):
                self.load_existing_profile()

    def draw(self) -> None:
        self.stdscr.erase()
        h, w = self.stdscr.getmaxyx()
        title = 'SymmCrypt TUI  |  Robust symmetric encryption toolkit + custom cipher lab'
        self.stdscr.addnstr(0, 1, title, w - 2, curses.A_BOLD)
        split = min(48, w // 2)
        for i, (path, label, kind) in enumerate(FIELD_SPECS):
            y = i + 2
            if y >= h - 8:
                break
            val = self._get_attr(path)
            disp = '******' if kind == 'secret' and val else str(val)
            attr = curses.A_REVERSE if i == self.idx else curses.A_NORMAL
            self.stdscr.addnstr(y, 1, f'{label:<18} {disp}', split - 2, attr)
        preview = pretty_json(self.job.to_dict())
        preview_lines = preview.splitlines()
        self.stdscr.addnstr(1, split + 1, 'Config preview', w - split - 2, curses.A_BOLD)
        for i, line in enumerate(preview_lines[: max(1, h - 10)]):
            self.stdscr.addnstr(i + 2, split + 1, line, w - split - 2)
        self.stdscr.hline(h - 6, 0, '-', w)
        self.stdscr.addnstr(h - 5, 1, 'Status', w - 2, curses.A_BOLD)
        lines = self.status_lines[-4:]
        for i, line in enumerate(lines):
            self.stdscr.addnstr(h - 4 + i, 1, line, w - 2)
        self.stdscr.refresh()

    def _get_attr(self, path: str):
        obj = self.job
        parts = path.split('.')
        for part in parts:
            obj = getattr(obj, part)
        return obj

    def _set_attr(self, path: str, value):
        obj = self.job
        parts = path.split('.')
        for part in parts[:-1]:
            obj = getattr(obj, part)
        setattr(obj, parts[-1], value)

    def edit_current(self) -> None:
        path, label, kind = FIELD_SPECS[self.idx]
        if kind == 'choice':
            self.cycle_choice(path)
            return
        current = self._get_attr(path)
        value = self.prompt(f'{label}: ', '' if kind == 'secret' else str(current))
        if value is None:
            return
        try:
            if kind == 'int':
                parsed = int(value, 0)
            elif kind == 'bool':
                parsed = value.lower() in {'1', 'true', 'yes', 'y', 'on'}
            else:
                parsed = value
            self._set_attr(path, parsed)
            self.status_lines.append(f'Updated {label}.')
        except Exception as exc:
            self.status_lines.append(f'Invalid value for {label}: {exc}')

    def toggle_current(self) -> None:
        path, label, kind = FIELD_SPECS[self.idx]
        if kind == 'bool':
            self._set_attr(path, not self._get_attr(path))
            self.status_lines.append(f'Toggled {label}.')
        elif kind == 'choice':
            self.cycle_choice(path)

    def cycle_choice(self, path: str) -> None:
        choices = CHOICES[path]
        current = self._get_attr(path)
        idx = choices.index(current)
        self._set_attr(path, choices[(idx + 1) % len(choices)])
        self.status_lines.append(f'{path} -> {self._get_attr(path)}')

    def prompt(self, label: str, default: str = '') -> str | None:
        h, w = self.stdscr.getmaxyx()
        win = curses.newwin(3, max(40, w - 8), max(1, h // 2 - 1), 4)
        win.box()
        win.addstr(1, 2, label)
        curses.echo()
        curses.curs_set(1)
        win.refresh()
        try:
            value = win.getstr(1, len(label) + 3, max(1, w - len(label) - 15)).decode('utf-8')
            if value == '' and default != '':
                value = default
            return value
        except KeyboardInterrupt:
            return None
        finally:
            curses.noecho()
            curses.curs_set(0)

    def execute_job(self) -> None:
        result = encrypt_job(self.job) if self.job.operation == 'encrypt' else decrypt_job(self.job)
        self.status_lines.append(result.message)
        if result.metadata:
            self.status_lines.extend(textwrap.wrap(pretty_json(result.metadata), width=110)[:3])
        if result.plaintext is not None and self.job.target == 'text':
            sample = result.plaintext[:160]
            try:
                view = sample.decode('utf-8', errors='replace')
            except Exception:
                view = repr(sample)
            self.status_lines.append(f'Preview: {view}')

    def run_benchmark(self) -> None:
        try:
            lines = run_benchmarks(self.job)
            self.status_lines.extend(lines[:8])
        except Exception as exc:
            self.status_lines.append(f'Benchmark failed: {exc}')

    def run_analysis(self) -> None:
        try:
            lines = run_custom_lab_analysis(self.job)
            self.status_lines.extend(lines[:8])
        except Exception as exc:
            self.status_lines.append(f'Analysis failed: {exc}')

    def save_current_profile(self) -> None:
        name = self.prompt('Profile name: ')
        if not name:
            return
        path = save_profile(self.job, name)
        self.status_lines.append(f'Saved profile -> {path}')

    def load_existing_profile(self) -> None:
        profiles = list_profiles()
        if not profiles:
            self.status_lines.append('No saved profiles.')
            return
        name = self.prompt(f'Profile name ({", ".join(profiles[:6])}): ')
        if not name:
            return
        try:
            self.job = load_profile(name)
            self.status_lines.append(f'Loaded profile: {name}')
        except Exception as exc:
            self.status_lines.append(f'Could not load profile {name}: {exc}')



def launch_tui() -> int:
    return curses.wrapper(lambda stdscr: TUI(stdscr).run())

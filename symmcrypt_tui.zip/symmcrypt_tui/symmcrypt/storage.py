from __future__ import annotations

import json
import struct
from typing import Any, Dict, Tuple

from .util import MAGIC


def pack_envelope(header: Dict[str, Any], ciphertext: bytes) -> bytes:
    head = json.dumps(header, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return MAGIC + struct.pack('>I', len(head)) + head + ciphertext



def unpack_envelope(blob: bytes) -> Tuple[Dict[str, Any], bytes]:
    if not blob.startswith(MAGIC):
        raise ValueError('Input does not look like a SYMKT1 encrypted file.')
    header_len = struct.unpack('>I', blob[len(MAGIC):len(MAGIC) + 4])[0]
    start = len(MAGIC) + 4
    end = start + header_len
    header = json.loads(blob[start:end].decode('utf-8'))
    return header, blob[end:]
